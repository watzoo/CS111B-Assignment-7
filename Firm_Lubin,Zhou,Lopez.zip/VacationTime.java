//********************************************************************
//  VacationTime.java       Author: Daniel Lubin , Gabriel Lopez, Calvin Zhou 
//
//  Represents an interface that returns an employees vacation time.
//********************************************************************

interface VacationTime{
    //-----------------------------------------------------------------
    //  Returns amount of vacation time.
    //-----------------------------------------------------------------
    public abstract int vacation();
}