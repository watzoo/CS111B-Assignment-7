//********************************************************************
//  VacationTime.java       Author: Daniel Lubin , Gabriel Lopez, Calvin Zhou 
//
//  Represents an interface that returns an employees vacation time.
//********************************************************************

interface VacationTime{

    final int STANDARD_VACATION = 14;
    //-----------------------------------------------------------------
    //  Returns amount of vacation time.
    //-----------------------------------------------------------------
    public abstract int vacation();
}