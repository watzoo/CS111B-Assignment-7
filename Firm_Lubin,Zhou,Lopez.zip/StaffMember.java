//********************************************************************
//  StaffMember.java       Author: Daniel Lubin , Calvin Zhou, Gabriel Lopez
//
//  Represents a generic staff member.
//********************************************************************

abstract public class StaffMember implements Payable, Comparable<StaffMember>, VacationTime
{
    
    protected String name;
    protected String address;
    protected String phone;

    //-----------------------------------------------------------------
    //  Constructor: Sets up this staff member using the specified
    //  information.
    //-----------------------------------------------------------------
    public StaffMember(String eName, String eAddress, String ePhone)
    {
        name = eName;
        address = eAddress;
        phone = ePhone;
    }

    //-----------------------------------------------------------------
    //  Returns a string including the basic employee information.
    //-----------------------------------------------------------------
    public String toString()
    {
        String result = "Name: " + name + "\n";

        result += "Address: " + address + "\n";
        result += "Phone: " + phone;

        return result;
    }

    //-----------------------------------------------------------------
    //  Returns a name.
    //-----------------------------------------------------------------
    public String getName(){
        return name;
    }

    //-----------------------------------------------------------------
    //  Compares names to overide the compareTo method.
    //-----------------------------------------------------------------
    public int compareTo(StaffMember otherMember)
    {
       return name.compareTo(otherMember.getName());
    }


    

}
