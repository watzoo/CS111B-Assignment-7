//********************************************************************
//  Payable.java       Author: Daniel Lubin , Gabriel Lopez, Calvin Zhou 
//
//  Represents an interface that returns an employees pay.
//********************************************************************
public interface  Payable{
    
    //-----------------------------------------------------------------
    //  Returns pay. 
    //-----------------------------------------------------------------
    abstract public double pay();
}