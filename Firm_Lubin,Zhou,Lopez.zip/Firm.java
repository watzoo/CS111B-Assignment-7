//-----------------------------------------------------------------
/*Algorithm
 * 1.Create staff for a firm.
 * 2. Assign name, address, and position.
 * 3. Assign Pay and vacation time based on position
 * 4. Assign Social security and phone number if avalaible.
 * 5. Sort in reverse alphabetical order by first name.
 * 6. Display list of employees with all info.
 */
//-----------------------------------------------------------------
// Author(s): Daniel Lubin , Gabriel Lopez, Calvin Zhou 
// Date of Last Modification: 11/29/2022
// Course: CS111B 
// Instructor: C. Conner 
// Assignment #7
// File Name: Firm.java
// This program displays each emplyyees pay, vacation time,name ,address, phonme number, and social security number as applicable in a firm.
//-----------------------------------------------------------------

public class Firm
{
    //-----------------------------------------------------------------
    //  Creates a staff of employees for a firm and pays them.
    //-----------------------------------------------------------------
    public static void main(String[] args)
    {
        Staff personnel = new Staff();
        personnel.sort();
        personnel.payday();
    }

}
